# Medibuddy: Smart Disease Predictor

## Sample images of the web application

### Home Page
<img src="images/Sample_Web_App_Images/sample1.png" alt="My cool logo"/>
<br>

### Diabetes Predictor
<img src="images/Sample_Web_App_Images/sample2.png" alt="My cool logo"/>
<br>

### Breast Cancer Predictor
<img src="images/Sample_Web_App_Images/sample3.png" alt="My cool logo"/>
<br>

### Malaria Predictor
<img src="images/Sample_Web_App_Images/sample4.png" alt="My cool logo"/>
<br>

### Negative Result Page
<img src="images/Sample_Web_App_Images/sample5.png" alt="My cool logo"/>
<br>

### Positive Result Page
<img src="images/Sample_Web_App_Images/sample6.png" alt="My cool logo"/>
